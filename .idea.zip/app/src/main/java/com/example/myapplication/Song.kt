package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

data class Song(
    val title : String = "",
    val singer : String = ""
//    val startTime : String = "",
//    val endTime : String = "",
//    val isplaying : Boolean = false
)